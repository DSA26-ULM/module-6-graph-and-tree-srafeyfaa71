#include <iostream>
#include <vector>
#include <string>
#include "RedBlackTree.h"

void printPreorder(const RedBlackTree::Node* node, const RedBlackTree::Node* nil) {
    if (node == nil) return;
    std::cout << " " << node->key;
    printPreorder(node->left, nil);
    printPreorder(node->right, nil);
}

void printInorder(const RedBlackTree::Node* node, const RedBlackTree::Node* nil) {
    if (node == nil) return;
    printInorder(node->left, nil);
    std::cout << " " << node->key;
    printInorder(node->right, nil);
}

void printPostorder(const RedBlackTree::Node* node, const RedBlackTree::Node* nil) {
    if (node == nil) return;
    printPostorder(node->left, nil);
    printPostorder(node->right, nil);
    std::cout << " " << node->key;
}

void handleQuery(const std::string& query, const RedBlackTree& tree) {
    if (tree.empty()) {
        std::cout << "Tree kosong. Tidak ada yang bisa ditampilkan.\n";
        return;
    }

    const RedBlackTree::Node* root = tree.root();
    const RedBlackTree::Node* nil = tree.nil();

    if (query == "PREORDER") {
        std::cout << "[Preorder]  :";
        printPreorder(root, nil);
        std::cout << "\n";
    } else if (query == "INORDER") {
        std::cout << "[Inorder]   :";
        printInorder(root, nil);
        std::cout << "\n";
    } else if (query == "POSTORDER") {
        std::cout << "[Postorder] :";
        printPostorder(root, nil);
        std::cout << "\n";
    } else if (query == "ALL") {
        std::cout << "[Preorder]  :";
        printPreorder(root, nil);
        std::cout << "\n";

        std::cout << "[Inorder]   :";
        printInorder(root, nil);
        std::cout << "\n";

        std::cout << "[Postorder] :";
        printPostorder(root, nil);
        std::cout << "\n";
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (!(std::cin >> n)) return 0;

    RedBlackTree tree;
    for (int i = 0; i < n; ++i) {
        int val;
        std::cin >> val;
        if (!tree.contains(val)) {
            tree.insert(val);
        }
    }

    int q;
    if (!(std::cin >> q)) return 0;

    for (int i = 0; i < q; ++i) {
        std::string query;
        std::cin >> query;
        handleQuery(query, tree);
    }

    return 0;
}