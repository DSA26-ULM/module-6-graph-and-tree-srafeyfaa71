#include <iostream>
#include <vector>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (!(std::cin >> n)) return 0;

    std::vector<char> vertices(n);
    for (int i = 0; i < n; ++i) {
        std::cin >> vertices[i];
    }

    std::cout << "Adjacency List:\n";

    for (int i = 0; i < n; ++i) {
        std::cout << vertices[i] << " -> ";
        bool has_edge = false;
        bool first = true;

        for (int j = 0; j < n; ++j) {
            int weight;
            std::cin >> weight;
            if (weight > 0) {
                if (!first) {
                    std::cout << ", ";
                }
                std::cout << "(" << vertices[j] << "," << weight << ")";
                first = false;
                has_edge = true;
            }
        }

        if (!has_edge) {
            std::cout << "-";
        }
        std::cout << "\n";
    }

    return 0;
}