#include <iostream>
#include <vector>
#include <string>
#include <map>

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int n;
    if (!(std::cin >> n)) return 0;

    std::vector<char> vertices(n);
    std::map<char, int> vertex_to_index;
    for (int i = 0; i < n; ++i) {
        std::cin >> vertices[i];
        vertex_to_index[vertices[i]] = i;
    }

    int m;
    std::cin >> m;

    std::vector<std::vector<int>> matrix(n, std::vector<int>(n, 0));

    for (int i = 0; i < m; ++i) {
        char u, v;
        int w;
        std::cin >> u >> v >> w;
        int idx_u = vertex_to_index[u];
        int idx_v = vertex_to_index[v];
        matrix[idx_u][idx_v] = w;
    }

    std::cout << "Adjacency Matrix:\n";
    std::cout << " ";
    for (int i = 0; i < n; ++i) {
        std::cout << " " << vertices[i];
    }
    std::cout << "\n";

    for (int i = 0; i < n; ++i) {
        std::cout << vertices[i];
        for (int j = 0; j < n; ++j) {
            std::cout << " " << matrix[i][j];
        }
        std::cout << "\n";
    }

    return 0;
}