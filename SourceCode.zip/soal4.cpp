#include <iostream>
#include <vector>

int r, c;
std::vector<std::vector<int>> grid;
std::vector<std::vector<bool>> visited;
int fr, fc;
int path_count = 0;

int dr[] = {-1, 1, 0, 0};
int dc[] = {0, 0, -1, 1};

void dfs(int cr, int cc) {
    if (cr == fr && cc == fc) {
        path_count++;
        return;
    }

    for (int i = 0; i < 4; ++i) {
        int nr = cr + dr[i];
        int nc = cc + dc[i];

        if (nr >= 0 && nr < r && nc >= 0 && nc < c) {
            if (grid[nr][nc] == 0 && !visited[nr][nc]) {
                visited[nr][nc] = true;
                dfs(nr, nc);
                visited[nr][nc] = false;
            }
        }
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    if (!(std::cin >> r >> c)) return 0;

    grid.assign(r, std::vector<int>(c));
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            std::cin >> grid[i][j];
        }
    }

    int sr, sc;
    std::cin >> sr >> sc >> fr >> fc;

    visited.assign(r, std::vector<bool>(c, false));
    visited[sr][sc] = true;

    dfs(sr, sc);

    std::cout << path_count << "\n";
    return 0;
}