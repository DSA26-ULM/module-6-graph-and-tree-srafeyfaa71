#include <iostream>
#include <vector>
#include <queue>

struct Cell {
    int r, c, dist;
};

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(NULL);

    int r, c;
    if (!(std::cin >> r >> c)) return 0;

    std::vector<std::vector<int>> grid(r, std::vector<int>(c));
    for (int i = 0; i < r; ++i) {
        for (int j = 0; j < c; ++j) {
            std::cin >> grid[i][j];
        }
    }

    int sr, sc, fr, fc;
    std::cin >> sr >> sc >> fr >> fc;

    std::vector<std::vector<bool>> visited(r, std::vector<bool>(c, false));
    std::queue<Cell> q;

    q.push({sr, sc, 0});
    visited[sr][sc] = true;

    int dr[] = {-1, 1, 0, 0};
    int dc[] = {0, 0, -1, 1};
    int result = -1;

    while (!q.empty()) {
        Cell curr = q.front();
        q.pop();

        if (curr.r == fr && curr.c == fc) {
            result = curr.dist;
            break;
        }

        for (int i = 0; i < 4; ++i) {
            int nr = curr.r + dr[i];
            int nc = curr.c + dc[i];

            if (nr >= 0 && nr < r && nc >= 0 && nc < c) {
                if (grid[nr][nc] == 0 && !visited[nr][nc]) {
                    visited[nr][nc] = true;
                    q.push({nr, nc, curr.dist + 1});
                }
            }
        }
    }

    std::cout << result << "\n";
    return 0;
}